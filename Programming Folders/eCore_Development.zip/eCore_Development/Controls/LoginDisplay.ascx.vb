﻿Imports System.Data.SqlClient

Partial Class Controls_LoginDisplay
    Inherits System.Web.UI.UserControl

    Protected Sub Page_PreRender(sender As Object, e As System.EventArgs) Handles Me.PreRender

        'Check for empid visible if not redirect
        'If Request("EMPID") = "" Then
        'Response.Redirect("Default2.aspx")
        'End If
        If Session("EMPID") = "" Then

            HyperLink1.ImageUrl = "../images/Vendor_Btn/eProScheduler.png"
            HyperLink2.ImageUrl = "../images/Vendor_Btn/eProManager.png"

            HyperLink1.NavigateUrl = "http://ecoresoftware.com/eproscheduler.html"
            HyperLink2.NavigateUrl = "http://ecoresoftware.com/epromanager.html"

            HyperLink1.Visible = True
            HyperLink2.Visible = True
            GoTo End_SUB

        End If




        'On Load find permission settings and display which box properly
        Dim SQLConn As New SqlConnection()
        Dim SQLCmd As New SqlCommand()
        Dim dr As SqlDataReader
        Dim dr2 As SqlDataReader
        Dim Integration As Integer

        Dim ConnString = "Data Source=ECORE-DEVELOPER\SQLEXPRESS;Initial Catalog=schedulerlite;User Id=ecore_dev;Password=login4dev;"

        Dim SQL1 As String = "SELECT * FROM PageOptions WHERE Name like 'ProgramConfig'"

        Dim SQL2 As String = "SELECT COUNT(ACCESSTYPE) as AccessTypeCount, COUNT(AccessKey) as AccessKeyCount, Application FROM [schedulerlite].[dbo].[EmployeeUserGroups] A " & _
                          "INNER JOIN  UserGroupAccess B ON (A.GroupID = B.GroupKey) " & _
                          "WHERE A.EmployeeID = '" & Session("EMPID") & "' Group by Application"

        SQLConn.ConnectionString = ConnString
        SQLConn.Open()



        '********************************************************
        ' Displays which system the customer has (PageOptions> ProgramConfig):
        '  Integrated config: 1)EPS 2)EPM 3) Both Systems
        '********************************************************

        SQLCmd.Connection = SQLConn
        SQLCmd.CommandText = SQL1
        dr = SQLCmd.ExecuteReader

        dr.Read()

        Integration = dr("Value")


        dr.Close()

        '********************************************************
        ' Find User permissons either basic or not
        '  Use Integrated access to view which system and permissions too.
        '********************************************************
        SQLCmd.Connection = SQLConn
        SQLCmd.CommandText = SQL2
        dr2 = SQLCmd.ExecuteReader

        While dr2.Read()
            If dr2("AccessTypeCount") > 1 And dr2("AccessKeyCount") > 1 Then
                'Display the proper button
                Select Case Integration
                    Case 1 'EPS
                        HyperLink1.ImageUrl = "../images/Vendor_Btn/eProSchedule_SignIn_Mgr.png"
                        HyperLink1.NavigateUrl = "http://" & Request.Url.Host & "/eps/main/login2.asp?Username=" & Session("UserName") & "&Password=" & Session("PassWord")

                        HyperLink1.Visible = True

                    Case 2 'EPM
                        HyperLink2.ImageUrl = "../images/Vendor_Btn/eProMgr_SignIn_Basic.png"
                        HyperLink2.NavigateUrl = "http://" & Request.Url.Host & "/epm/main/login2.asp?Username=" & Session("UserName") & "&Password=" & Session("PassWord")

                        HyperLink2.Visible = True


                    Case 3 'Both Systems
                        HyperLink1.ImageUrl = "../images/Vendor_Btn/eProSchedule_SignIn_Mgr.png"
                        HyperLink2.ImageUrl = "../images/Vendor_Btn/eProMgr_SignIn_Basic.png"

                        HyperLink1.NavigateUrl = "http://" & Request.Url.Host & "/eps/main/login2.asp?Username=" & Session("UserName") & "&Password=" & Session("PassWord")
                        HyperLink2.NavigateUrl = "http://" & Request.Url.Host & "/epm/main/login2.asp?Username=" & Session("UserName") & "&Password=" & Session("PassWord")

                        HyperLink1.Visible = True
                        HyperLink2.Visible = True
                End Select
            Else

                HyperLink1.ImageUrl = "../images/Vendor_Btn/eProSchedule_SignIn_Basic.png"
                HyperLink1.NavigateUrl = "http://" & Request.Url.Host & "/eps/main/login2.asp?Username=" & Session("UserName") & "&Password=" & Session("PassWord")
                HyperLink1.Visible = True
                HyperLink2.Visible = False

            End If


        End While

        dr.Close()
        dr2.Close()

        SQLConn.Close()
        SQLConn.Dispose()
End_SUB:


    End Sub

 
End Class
