﻿Imports System.Data.SqlClient

Partial Class _Default
    Inherits System.Web.UI.Page
    Protected Sub Submit_Button_Click(sender As Object, e As System.EventArgs) Handles Submit_Button.Click
        Search_User(UserName_TextBox.Text, Password_TextBox.Text)


    End Sub

    Protected Sub Confirm_Button_Click(sender As Object, e As System.EventArgs) Handles Confirm_Button.Click
        Dim SQL2 As String = "Update [schedulerlite].dbo.Employee " & _
                              "SET Password='" & ConfirmPWD_TextBox.Text & "', PasswordLastChanged=SYSDATETIME(), PasswordIsSet=1 " & _
                              " WHere EMPID = '" & EMPID_Hidden.Value.ToString() & "'"
        Dim test As String = EMPID_Hidden.Value.ToString()
        SqlDataSource1.UpdateCommand = SQL2
        SqlDataSource1.Update()

        'Dispplay update successful
        Change_PWD_Panel.Visible = False
        ConfirmUpdate_Panel.Visible = True
    End Sub

    Protected Sub OK_Button_Click(sender As Object, e As System.EventArgs) Handles OK_Button.Click
        'Display correct login
        Search_User(UserName_TextBox.Text, Password_TextBox.Text)
    End Sub


    Public Sub Search_User(ByVal User_Name As String, ByVal Password As String)
        'Check to see if the password needs to be reset
        Dim SQLConn As New SqlConnection()
        Dim SQLCmd As New SqlCommand()
        Dim dr As SqlDataReader

        Dim ConnString = "Data Source=ECORE-DEVELOPER\SQLEXPRESS;Initial Catalog=schedulerlite;User Id=ecore_dev;PASSWORD=login4dev"
        Dim SQL1 As String = "SELECT EMPID, USERNAME, PASSWORD, PASSWORDISSET,ISNULL(DATEDIFF(day,sysdatetime(),PasswordLastChanged), 90) as Pwd_Diff  FROM [schedulerlite].dbo.Employee WHere UserName = '" & User_Name & "'"

        SQLConn.ConnectionString = ConnString
        SQLConn.Open()

        SQLCmd.Connection = SQLConn
        SQLCmd.CommandText = SQL1
        dr = SQLCmd.ExecuteReader

        '*******************************************
        ' If user not in system displays message   * 
        '*******************************************
        If dr.Read() = False Then
            'Create redirect here to new popup
            'Message_Label.Text = "Your user Id is not in the system.  Please contact your administrator."

            '********************************************************
            ' If user or password not correct displays message      * 
            '********************************************************
        ElseIf UCase(User_Name) <> UCase(dr("UserName")) Or Password <> dr("Password") Then
            'Message_Label.Text = "Invalid ID or password.  Please try again."

            '********************************************************
            ' If password has expired or is not set then they reset *
            ' it.                                                   * 
            ' DB: Employee
            ' Fields: PASSWORDISSET, PasswordLastChanged
            '********************************************************
        ElseIf dr("PASSWORDISSET") = 0 Or dr("Pwd_Diff") >= 90 Then
            EMPID_Hidden.Value = dr("EMPID")
            Change_PWD_Panel.Visible = True


        Else
            'EMPID_Hidden.Value = dr("EMPID")
            'dr.Close()
            'SQLConn.Close()
            'SQLConn.Dispose()

            '********************************************************
            ' After user has changed user name and password         *
            ' gets redirected to splash page without URL changing   *
            '********************************************************
            SignIn_Panel.Visible = False
            SignIn_LinkButton.Visible = False
            ConfirmUpdate_Panel.Visible = False
            Display_Label.Text = "User ID: " & dr("UserName") & "<br />Emp No.: " & dr("EMPID")
            Display_Label.Visible = True
            Display_Panel.Visible = True

        End If
        dr.Close()
        SQLConn.Close()
        SQLConn.Dispose()
    End Sub
End Class
