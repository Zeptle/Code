﻿
Partial Class Controls_Login_Session
    Inherits System.Web.UI.UserControl

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        UserName_TextBox.Text = Session("UserName")
    End Sub
End Class
