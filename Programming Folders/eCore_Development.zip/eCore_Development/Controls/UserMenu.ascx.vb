﻿
Partial Class Controls_UserMenu
    Inherits System.Web.UI.UserControl

End Class
