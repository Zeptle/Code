﻿Imports System.Net.Mail
Imports System.Data.SqlClient

Partial Class Controls_Forgotten_Password
    Inherits System.Web.UI.UserControl

    Private Sub SendEmail(Email_Address As String, EMPID As String)

        'Send Email in this function
        Dim myMessage As MailMessage = New MailMessage
        Dim messageBody As String

        messageBody = "<p>You recently requested a new password to sign in to your account. Below is your temporary password to sign in: </p> " & _
                      "<p>Temporary Password: E1MEp" & Date.DaysInMonth(Year(Now), Month(Now)) + 3 & EMPID + 10 & "</p>" & _
                      "<p>This request was made on " & DateTime.Now.ToString("hh:mm dddd, dd MMMM yyyy") & ".  " & _
                      "<p>For security reasons, the password will expire at in 24 hours or after you reset your password.</p> " & _
                      "Regards,<br /> eCore Account Services <br />******************************************************** <br />Please do not reply to this message. Mail sent to this address cannot be answered. "

        myMessage.Subject = "eCore Password Reset Request"
        myMessage.Body = messageBody
        myMessage.IsBodyHtml = True
        myMessage.From = New MailAddress("Support@ecoresoftware.com", "eCore Webmaster")
        myMessage.To.Add(New MailAddress(Email_Address))


        Dim mySmtpClient As SmtpClient = New SmtpClient()
        'mySmtpClient.Send(myMessage)

    End Sub
    Protected Sub Submit_Button_Click(sender As Object, e As System.EventArgs) Handles Submit_Button.Click



        '********* DB Connetion Begin **********
        Dim SQLConn As New SqlConnection()
        Dim SQLCmd As New SqlCommand()
        Dim dr As SqlDataReader

        Dim ConnString = "Data Source=ECORE-DEVELOPER\SQLEXPRESS;Initial Catalog=schedulerlite;User Id=ecore_dev;Password=login4dev;"
        Dim SQL1 As String = "SELECT EMailAddress, SUBSTRING(EmpID, 1, 2) as SUBEMPID, EMPID, DATEDIFF(day,sysdatetime(),PasswordLastChanged) as Pwd_Diff  FROM [schedulerlite].dbo.Employee Where UserName = '" & UserName_TextBox.Text & "'"

        SQLConn.ConnectionString = ConnString
        SQLConn.Open()

        SQLCmd.Connection = SQLConn
        SQLCmd.CommandText = SQL1
        dr = SQLCmd.ExecuteReader

        '*******************************************
        ' If user not in system displays message   * 
        '*******************************************
        If dr.Read() = False Then
            Message_Label.Text = "Your user Id is not in the system.  Please contact your administrator."
            Message_Label.Visible = True
        Else
            '****************************************************
            ' If user has forgotten password it sends an email  *
            ' and updates the user with a temporary password    * 
            '****************************************************

            'Update User DB with Temp Password
            Dim SQL2 As String = "Update [schedulerlite].dbo.Employee " & _
                                 "SET Password='E1MEp" & Date.DaysInMonth(Year(Now), Month(Now)) + 3 & dr("SUBEMPID") + 10 & "', PasswordLastChanged=SYSDATETIME(), PasswordIsSet=0 " & _
                                 "WHERE EmpID ='" & dr("EMPID") & "'"

            LostPwd_SqlDataSource.UpdateCommand = SQL2
            LostPwd_SqlDataSource.Update()
            SendEmail(dr("EmailAddress"), CStr(dr("EMPID")))
            Reset_Panel.Visible = False

        End If
        dr.Close()
        SQLConn.Close()
        SQLConn.Dispose()

        Session("UserName") = UserName_TextBox.Text

        ' Display message
        Message_Label.Text = "Please check your inbox for instructions on retrieving your password. <br />"
        AppEnd_Panel1.Visible = True
        Reset_Panel.Visible = False

    End Sub

    Protected Sub OK_Button_Click(sender As Object, e As System.EventArgs) Handles OK_Button.Click
        'Figure something out here
        Session.Clear()
        Session.Abandon()
        Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1))
        Response.Cache.SetCacheability(HttpCacheability.NoCache)
        Response.Cache.SetNoStore()
        Response.Redirect("~/Default2.aspx")

    End Sub
End Class
