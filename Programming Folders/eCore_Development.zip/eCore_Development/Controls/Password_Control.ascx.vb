﻿Imports System.Data.SqlClient
Partial Class Password_Control
    Inherits System.Web.UI.UserControl

    
    Protected Sub Confirm_Button_Click(sender As Object, e As System.EventArgs) Handles Confirm_Button.Click
        Dim SQL2 As String = "Update [schedulerlite].dbo.Employee " & _
                             "SET Password='" & ConfirmPWD_TextBox.Text & "', PasswordLastChanged=SYSDATETIME(), PasswordIsSet=1 " & _
                             " WHere EMPID = '" & Session("EMPID") & "'"

        Pwd_SqlDataSource.UpdateCommand = SQL2
        Pwd_SqlDataSource.Update()

        'Display update successful
        Change_PWD_Panel.Visible = False
        ConfirmUpdate_Panel.Visible = True
    End Sub

    Protected Sub OK_Button_Click(sender As Object, e As System.EventArgs) Handles OK_Button.Click
        Session.Clear()
        Session.Abandon()
        Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1))
        Response.Cache.SetCacheability(HttpCacheability.NoCache)
        Response.Cache.SetNoStore()
        Response.Redirect("~/Default2.aspx")
    End Sub
End Class
