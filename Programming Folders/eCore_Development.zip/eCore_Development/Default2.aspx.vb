﻿Imports System.Net.Mail
Imports System.Data.SqlClient
Partial Class Default2
    Inherits System.Web.UI.Page
    Public EMPID As String

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load


        'Check to see if the password needs to be reset
        Dim SQLConn As New SqlConnection()
        Dim SQLCmd As New SqlCommand()
        Dim dr As SqlDataReader

        Dim ConnString = "Data Source=ECORE-DEVELOPER\SQLEXPRESS;Initial Catalog=schedulerlite;User Id=ecore_dev;PASSWORD=login4dev"
        Dim SQL1 As String = "SELECT [Name] FROM [schedulerlite].[dbo].[Organization]"

        SQLConn.ConnectionString = ConnString
        SQLConn.Open()

        SQLCmd.Connection = SQLConn
        SQLCmd.CommandText = SQL1
        dr = SQLCmd.ExecuteReader


        dr.Read()

        HeaderDisplay_Label.Text = dr("Name")

        'Display title here
        dr.Close()
        SQLConn.Close()
        SQLConn.Dispose()
    End Sub

    Protected Sub Password_LinkButton_Click(sender As Object, e As System.EventArgs) Handles Password_LinkButton.Click
        'Declare variables
        Forgotten_Password.Visible = True
        LoginDisplay.Visible = False
        
    End Sub




    Protected Sub LinkButton4_Click(sender As Object, e As System.EventArgs) Handles LinkButton4.Click
        Session.Clear()
        Session.Abandon()
        Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1))
        Response.Cache.SetCacheability(HttpCacheability.NoCache)
        Response.Cache.SetNoStore()
        Response.Redirect("Default2.aspx")
        
    End Sub

    Protected Sub Submit_Button_Click(sender As Object, e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        Search_User(UserName_TextBox.Text, Password_TextBox.Text)
        LinkButton4.Enabled = True
    End Sub

    Public Sub Search_User(ByVal User_Name As String, ByVal Password As String)

        'Check to see if the password needs to be reset
        Dim SQLConn As New SqlConnection()
        Dim SQLCmd As New SqlCommand()
        Dim dr As SqlDataReader

        Dim ConnString = "Data Source=ECORE-DEVELOPER\SQLEXPRESS;Initial Catalog=schedulerlite;User Id=ecore_dev;PASSWORD=login4dev"
        Dim SQL1 As String = "SELECT EMPID, USERNAME, PASSWORD, PASSWORDISSET,ISNULL(DATEDIFF(day,sysdatetime(),PasswordLastChanged), 90) as Pwd_Diff  FROM [schedulerlite].dbo.Employee Where UserName = '" & User_Name & "'"

        SQLConn.ConnectionString = ConnString
        SQLConn.Open()

        SQLCmd.Connection = SQLConn
        SQLCmd.CommandText = SQL1
        dr = SQLCmd.ExecuteReader

        '*******************************************
        ' If user not in system displays message   * 
        '*******************************************
        If dr.Read() = False Then
            'Create redirect here to new popup
            Message_Label.Text = "Your user Id is not in the system.  Please contact your administrator."
        ElseIf UCase(User_Name) <> UCase(dr("UserName")) Or Password <> dr("Password") Then

            Message_Label.Text = "Invalid ID or password.  Please try again."
        ElseIf dr("PASSWORDISSET") = 0 Or dr("Pwd_Diff") <= -90 Then

            'Create Session Variables Here
            Session("UserName") = UserName_TextBox.Text
            Session("PassWord") = Password_TextBox.Text
            Session("EMPID") = dr("EMPID")

            LoginDisplay.Visible = False
            Password1.Visible = True
        Else

            'dr.Close()
            'SQLConn.Close()
            'SQLConn.Dispose()

            '********************************************************
            ' After user has changed user name and password         *
            ' gets redirected to splash page without URL changing   *
            '********************************************************
            SignIn_Panel.Visible = False
            SignIn_LinkButton.Visible = False

            'ConfirmUpdate_Panel.Visible = False
            Display_Label.Text = "User ID: " & dr("UserName") & "<br />Emp No.: " & dr("EMPID")
            Display_Label.Visible = True
            LoginDisplay.Visible = True
            ' LoginDisplay.EMPID = dr("EMPID")

            'Create Session Variables Here
            Session("UserName") = UserName_TextBox.Text
            Session("PassWord") = Password_TextBox.Text
            Session("EMPID") = dr("EMPID")

        End If
        dr.Close()
        SQLConn.Close()
        SQLConn.Dispose()
    End Sub

End Class
